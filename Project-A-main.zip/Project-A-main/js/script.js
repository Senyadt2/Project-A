var section1 = document.querySelector("#section1");
var explore = document.querySelector(".explore");

explore.addEventListener("click",function(){
    section1.style.transform = "translateY(-100%)"
});